# Drag-and-Drop Page Builder

A mini page builder built with React and TypeScript. It lets users add blocks to a canvas, rearrange them using drag and drop, edit their properties, and save or load layouts as JSON.

The goal of this project was to build a simple, usable editor while keeping the code organized, drag interactions responsive, and imported data safe to handle.

## Features

- **Add blocks:** Add Text, Image, Button, and Container blocks from the palette, by dragging them onto the canvas or clicking them to add at the end.
- **Drag and drop:** Drag blocks to change their order on the page. A blue line shows where the block will land.
- **Edit properties:** Select a block and update its text, URL, colours, font size, height, alignment, and width. Changes appear on the canvas immediately.
- **Undo and redo:** Revert or restore changes, with a history of up to 50 steps.
- **Save and load:** Save the layout in the browser (localStorage). The saved layout is restored automatically when the page reloads.
- **JSON import and export:** Download the layout as a JSON file, or import a layout from a JSON file.
- **Validation:** Imported data is checked before it is applied to the canvas.
- **Responsive layout:** The interface adapts to different screen sizes. On phone-sized screens, every block becomes full width.
- **Keyboard support:** Use the Move up and Move down buttons to reorder blocks without dragging.
- **Keyboard shortcuts:** Use Ctrl+Z to undo and Ctrl+Y (or Ctrl+Shift+Z) to redo.

## Getting Started

### Requirements

- Node.js 18 or later
- npm

### Installation

Unzip the project, open the `dnd-builder` folder in a terminal, and install the dependencies:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

Open the local URL shown in your terminal, usually `http://localhost:5173`.

No API keys or environment variables are required.

### Available Scripts

```bash
npm run dev       # Start the development server
npm test          # Run unit tests
npm run build     # Create a production build
npm run lint      # Run linting
npm run preview   # Preview the production build
```

## Project Structure

```text
src/
├── components/
│   ├── Canvas.tsx
│   ├── Palette.tsx
│   ├── Block.tsx
│   ├── PropertiesPanel.tsx
│   └── Toolbar.tsx
├── hooks/
│   └── useBuilder.ts
├── state/
│   ├── builderReducer.ts
│   └── builderReducer.test.ts
├── types/
│   └── block.ts
├── utils/
│   ├── serialize.ts
│   ├── validate.ts
│   ├── validate.test.ts
│   └── helpers.ts
├── App.tsx
├── main.tsx
└── index.css
```

The components handle the user interface, the `useBuilder` hook holds the builder logic, the reducer manages state changes, and the utility functions handle validation and serialization.

## How It Works

### State Management

The builder uses a single `useReducer` state to keep track of the blocks, the selected block, and the undo/redo history.

State updates are handled through defined actions (add, move, update, delete, select, load, undo, redo) rather than being spread across individual components. The canvas is drawn from this state, and saving and exporting read from the same state, so it is the single source of truth.

### Drag and Drop

The builder uses the native HTML5 drag-and-drop API.

When a drag starts, a small message is attached to it: either "add a new block of this type" (from the palette) or "move this block" (from the canvas). This message is checked on drop, so anything else dropped on the page, such as text from another website, is ignored.

While dragging, only the drop marker updates, and only when the drop position changes. The layout itself is updated once, when the block is dropped. Dropping outside the canvas changes nothing.

### Editing Block Properties

When a block is selected, its properties appear in the properties panel. Each change replaces only the selected block's object; all other blocks stay exactly as they were.

Stable block IDs help the application identify blocks consistently when their order changes.

### Undo and Redo

The state keeps a list of earlier versions of the layout. Every change saves the previous version, and undo restores it. Selecting a block is not saved as a step, because it doesn't change the layout. The history is limited to 50 steps.

### Saving and Loading

Layouts can be saved in the browser and are restored automatically on reload. JSON export and import make it possible to move layouts between browsers or share them as files.

Saved and imported data is validated before it is used to update the builder state.

## Performance

The main performance consideration was avoiding unnecessary renders during drag operations and block editing.

- Action functions are created with `useCallback`, so their references stay the same and don't cause re-renders.
- Blocks are memoized with `React.memo`, so a block only re-renders when its own props change.
- Blocks do not receive their position number as a prop, so reordering does not cause every block to re-render just because its index changed.
- Repeated drag-over events are ignored unless the drop position changes.
- Stable IDs are used as React keys, so React moves existing elements when blocks are reordered instead of re-creating them.

### Profiling Notes

The following measurements were recorded with 300 blocks by counting how many times the `Block` component rendered during each action.

| Action | Blocks re-rendered (out of 300) |
|---|---:|
| Drag a block and drop it in a new position | 2 |
| 200 drag-over events on the same spot | 1 |
| Type 5 characters in the selected block | 5 (only that block) |
| Select a different block | 2 (old and new selection) |
| Undo one edit | 1 |

Without `React.memo` and the techniques above, each of these actions would re-render all 300 blocks. To see this yourself, open React DevTools → Profiler, turn on "Highlight updates when components render", and drag a block: only the affected blocks flash.

## Security and Data Validation

User input and imported JSON are treated as untrusted.

- **Render user input safely:** User text is displayed as plain text in JSX, which React escapes. `dangerouslySetInnerHTML` is never used, and a lint rule blocks it.
- **Safe URLs:** Only full `http://` or `https://` addresses are used. `javascript:`, `data:`, and similar URLs are blocked, and the URL is checked again right before it is used in an image or link. Links open with `rel="noopener noreferrer"`.
- **Safe styles:** Colours must be `#rrggbb` hex values, font size and height are limited to a fixed range, and alignment and width must be one of the allowed options.
- **Validate imported data:** The file is parsed with `JSON.parse` (never `eval`), and its structure and block types are checked before it is applied.
- **Only known fields:** Each block is rebuilt from known fields only. Unknown fields are dropped, and invalid values are replaced with defaults.
- **Handle invalid data safely:** Malformed files are rejected, and invalid blocks inside an otherwise valid file are skipped with a message.
- **Validate IDs:** Invalid or duplicate block IDs are replaced with new ones.
- **Size limits:** Imports are limited to 1 MB and 500 blocks, and text is limited to 1,000 characters.
- **Browser storage:** Saved layouts are validated when loaded, because localStorage can be edited outside the app.
- **Safe export:** The exported JSON contains only block data, and unsafe URLs are removed.
- **No secrets:** The app has no API keys or tokens, and `.env` files are ignored by Git.

This ensures that malformed or unexpected input cannot corrupt the builder state or introduce unsafe content into the interface.

## Edge Cases

| Scenario | Handling |
|---|---|
| Empty canvas | A message explains how to add the first block. |
| No block selected | The properties panel asks the user to select a block. |
| Delete a block | The block is removed and the selection is cleared. |
| Drop outside the canvas | The layout stays unchanged. |
| Rapid drag operations | Repeated drag events are ignored unless the drop position changes, and each drop is one state update. |
| Invalid JSON | The import is rejected with an error message, and the current layout stays unchanged. |
| Partly invalid JSON | Valid blocks are loaded and invalid ones are skipped with a message. |
| Missing block properties | Default values are used. |
| Duplicate or invalid IDs | New IDs are generated. |
| Reload the page | The saved layout is restored automatically. |
| Browser storage full or disabled | An error message is shown. |
| Nothing left to undo or redo | The Undo or Redo button is disabled. |

## Testing

The project uses Vitest for unit tests.

```bash
npm test
```

The 18 tests cover:

- **Reducer:** adding, moving, updating only the edited block, rejecting unsafe values, deleting, and undo/redo.
- **Validation:** safe URLs, rejecting invalid JSON and wrong file shapes, skipping invalid blocks, and replacing duplicate IDs.
- **Round trip:** an exported layout imports back exactly.

## JSON Format

A layout is a JSON object with a version number and an ordered list of blocks:

```json
{
  "version": 1,
  "blocks": [
    {
      "id": "block1",
      "type": "button",
      "text": "Click me",
      "url": "https://example.com/",
      "color": "#ffffff",
      "background": "#2563eb",
      "fontSize": 18,
      "height": 160,
      "align": "center",
      "width": "third"
    }
  ]
}
```

The order of `blocks` is the order on the page. The `text` field is the content for text blocks, the label for buttons, the alt text for images, and the title for containers. The `url` field is the image address for images and the link for buttons.

## Libraries and Tools

- **React:** Builds the user interface and reusable components.
- **TypeScript:** Adds static typing for components, block data, and state updates.
- **Vite:** Provides the development server and production build tooling.
- **Vitest:** Runs the unit tests.
- **Native HTML5 drag and drop:** Handles dragging and dropping, so no drag-and-drop library is needed.

## Possible Improvements

Given more time, I would consider:

- Adding drag-and-drop support for touch screens.
- Free positioning of blocks on a grid, with snap-to-grid.
- Nested containers (blocks inside a container).
- Component tests with React Testing Library.

## Conclusion

This project brings together component design, state management, drag-and-drop interactions, performance optimization, and input validation in a small React application.

The main focus was to keep the builder easy to use while making its state changes predictable and its interactions responsive. It also provided an opportunity to work through practical concerns such as undo/redo, JSON handling, and rendering behavior as the number of blocks increases.