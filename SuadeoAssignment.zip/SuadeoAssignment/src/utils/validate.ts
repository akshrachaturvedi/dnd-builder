import { ALIGNS, BLOCK_TYPES, WIDTHS, type Align, type Block, type BlockType, type BlockWidth } from '../types/block';
import {
  FONT_SIZE,
  HEIGHT,
  MAX_BLOCKS,
  TEXT_MAX_LENGTH,
  URL_MAX_LENGTH,
  clamp,
  cleanText,
  createBlock,
  createId,
  isHexColor,
  safeUrl,
} from './helpers';

const ID_PATTERN = /^[a-zA-Z0-9]{1,40}$/;
const MAX_FILE_SIZE = 1024 * 1024; // 1 MB

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function toNumber(value: unknown, min: number, max: number, fallback: number): number {
  return typeof value === 'number' && Number.isFinite(value) ? clamp(Math.round(value), min, max) : fallback;
}

/**
 * Builds a clean Block from untrusted data.
 * - Only known fields are copied; anything else is ignored.
 * - Every field is type-checked; bad values fall back to the default.
 * Returns null if the block type is unknown.
 * Used for property edits, imports and localStorage, so all paths follow the same rules.
 */
export function sanitizeBlock(raw: unknown): Block | null {
  if (!isObject(raw)) return null;
  const type = raw.type;
  if (typeof type !== 'string' || !BLOCK_TYPES.includes(type as BlockType)) return null;

  const defaults = createBlock(type as BlockType);
  return {
    id: typeof raw.id === 'string' && ID_PATTERN.test(raw.id) ? raw.id : defaults.id,
    type: defaults.type,
    text: typeof raw.text === 'string' ? cleanText(raw.text, TEXT_MAX_LENGTH) : defaults.text,
    url: typeof raw.url === 'string' ? cleanText(raw.url, URL_MAX_LENGTH) : defaults.url,
    color: isHexColor(raw.color) ? raw.color : defaults.color,
    background: isHexColor(raw.background) ? raw.background : defaults.background,
    fontSize: toNumber(raw.fontSize, FONT_SIZE.min, FONT_SIZE.max, defaults.fontSize),
    height: toNumber(raw.height, HEIGHT.min, HEIGHT.max, defaults.height),
    align: ALIGNS.includes(raw.align as Align) ? (raw.align as Align) : defaults.align,
    width: WIDTHS.includes(raw.width as BlockWidth) ? (raw.width as BlockWidth) : defaults.width,
  };
}

/** For import/export: an unsafe URL is removed completely. */
export function withSafeUrl(block: Block): Block {
  return { ...block, url: safeUrl(block.url) ?? '' };
}

export type ParseResult = { ok: true; blocks: Block[]; skipped: number } | { ok: false; error: string };

/** Never trust an imported layout: check size, JSON syntax, shape and every block. */
export function parseLayout(json: string): ParseResult {
  if (json.length > MAX_FILE_SIZE) return { ok: false, error: 'The file is too large (max 1 MB).' };

  let data: unknown;
  try {
    data = JSON.parse(json);
  } catch {
    return { ok: false, error: 'The file is not valid JSON.' };
  }

  if (!isObject(data) || data.version !== 1 || !Array.isArray(data.blocks)) {
    return { ok: false, error: 'This is not a layout file from this builder.' };
  }
  if (data.blocks.length > MAX_BLOCKS) {
    return { ok: false, error: `The layout has more than ${MAX_BLOCKS} blocks.` };
  }

  const blocks: Block[] = [];
  const usedIds = new Set<string>();
  let skipped = 0;

  for (const raw of data.blocks) {
    const block = sanitizeBlock(raw);
    if (!block) {
      skipped += 1;
      continue;
    }
    if (usedIds.has(block.id)) block.id = createId(); // duplicate id → give it a new one
    usedIds.add(block.id);
    blocks.push(withSafeUrl(block));
  }

  if (data.blocks.length > 0 && blocks.length === 0) {
    return { ok: false, error: 'None of the blocks in this file are valid.' };
  }
  return { ok: true, blocks, skipped };
}
