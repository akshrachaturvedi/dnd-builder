import type { Block } from '../types/block';
import { parseLayout, withSafeUrl, type ParseResult } from './validate';

const STORAGE_KEY = 'dnd-builder-layout';

/** Layout → JSON. Only block data is written, and unsafe URLs are removed. */
export function toJson(blocks: Block[]): string {
  return JSON.stringify({ version: 1, blocks: blocks.map(withSafeUrl) }, null, 2);
}

export function downloadJson(json: string, fileName: string): void {
  const url = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  URL.revokeObjectURL(url);
}

export function saveToStorage(blocks: Block[]): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, toJson(blocks));
    return true;
  } catch {
    return false; // storage full or disabled
  }
}

/** Saved data is validated like an import, because localStorage can be edited by anyone. */
export function loadFromStorage(): ParseResult | null {
  try {
    const json = localStorage.getItem(STORAGE_KEY);
    return json === null ? null : parseLayout(json);
  } catch {
    return null;
  }
}
