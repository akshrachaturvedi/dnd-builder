import { describe, expect, it } from 'vitest';
import { createBlock, safeUrl } from './helpers';
import { toJson } from './serialize';
import { parseLayout, sanitizeBlock } from './validate';

describe('safeUrl', () => {
  it('accepts http and https addresses', () => {
    expect(safeUrl('https://example.com')).toBe('https://example.com/');
    expect(safeUrl('http://example.com/a.png')).toBe('http://example.com/a.png');
  });

  it('rejects dangerous or incomplete addresses', () => {
    for (const url of ['javascript:alert(1)', 'JAVASCRIPT:alert(1)', 'data:text/html,<script>', 'vbscript:x', '/relative', 'example.com', '']) {
      expect(safeUrl(url)).toBeNull();
    }
  });
});

describe('sanitizeBlock', () => {
  it('returns null for unknown block types', () => {
    expect(sanitizeBlock({ type: 'script' })).toBeNull();
    expect(sanitizeBlock('not an object')).toBeNull();
  });

  it('keeps only known fields and replaces bad values with defaults', () => {
    const block = sanitizeBlock({ type: 'text', text: 'Hi', color: 'red', fontSize: 'big', onClick: 'alert(1)' });
    expect(block).not.toBeNull();
    expect(block?.text).toBe('Hi');
    expect(block?.color).toBe('#1f2937');
    expect(block?.fontSize).toBe(18);
    expect(block && 'onClick' in block).toBe(false);
  });
});

describe('parseLayout', () => {
  it('rejects invalid JSON', () => {
    expect(parseLayout('{oops').ok).toBe(false);
  });

  it('rejects files that are not layouts', () => {
    expect(parseLayout('[]').ok).toBe(false);
    expect(parseLayout('{"version":2,"blocks":[]}').ok).toBe(false);
    expect(parseLayout('{"version":1}').ok).toBe(false);
  });

  it('skips invalid blocks and removes unsafe URLs', () => {
    const json = JSON.stringify({
      version: 1,
      blocks: [{ type: 'button', text: 'Go', url: 'javascript:alert(1)' }, { type: 'evil' }],
    });
    const result = parseLayout(json);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.blocks).toHaveLength(1);
    expect(result.blocks[0].url).toBe('');
    expect(result.skipped).toBe(1);
  });

  it('gives duplicate ids a new id', () => {
    const block = { type: 'text', id: 'same' };
    const result = parseLayout(JSON.stringify({ version: 1, blocks: [block, block] }));
    expect(result.ok && result.blocks[0].id !== result.blocks[1].id).toBe(true);
  });

  it('round-trips an exported layout exactly', () => {
    const blocks = [createBlock('text'), { ...createBlock('button'), url: 'https://example.com/' }];
    const result = parseLayout(toJson(blocks));
    expect(result.ok && result.blocks).toEqual(blocks);
  });
});
