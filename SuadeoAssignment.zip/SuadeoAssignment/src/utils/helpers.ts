import { BLOCK_TYPES, type Block, type BlockType } from '../types/block';

export const MAX_BLOCKS = 500;
export const TEXT_MAX_LENGTH = 1000;
export const URL_MAX_LENGTH = 2000;
export const FONT_SIZE = { min: 12, max: 72 };
export const HEIGHT = { min: 60, max: 600 };

export const BLOCK_LABELS: Record<BlockType, string> = {
  text: 'Text',
  image: 'Image',
  button: 'Button',
  container: 'Container',
};

export function createId(): string {
  return 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/** Default values for a new block of each type. */
export function createBlock(type: BlockType): Block {
  const base: Block = {
    id: createId(),
    type,
    text: '',
    url: '',
    color: '#1f2937',
    background: '#ffffff',
    fontSize: 18,
    height: 160,
    align: 'left',
    width: 'full',
  };
  switch (type) {
    case 'text':
      return { ...base, text: 'Write your text here' };
    case 'image':
      return { ...base, text: 'Image description', height: 200, width: 'half' };
    case 'button':
      return { ...base, text: 'Click me', color: '#ffffff', background: '#2563eb', align: 'center', width: 'third' };
    case 'container':
      return { ...base, text: 'Section title', background: '#eef2ff', height: 160 };
  }
}

export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Only #rrggbb colours — a colour field can't carry any other CSS. */
export function isHexColor(value: unknown): value is string {
  return typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
}

/** Removes invisible control characters and limits the length. */
export function cleanText(value: string, maxLength: number): string {
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').slice(0, maxLength);
}

/**
 * Returns the URL if it is a full http:// or https:// address, otherwise null.
 * This blocks javascript:, data: and other dangerous URL types.
 */
export function safeUrl(value: string): string | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  try {
    const url = new URL(trimmed);
    return url.protocol === 'http:' || url.protocol === 'https:' ? url.href : null;
  } catch {
    return null;
  }
}

/* ---------- drag data (what we put in the browser's drag event) ---------- */

const DRAG_TYPE = 'application/x-dnd-builder';

export type DragData = { kind: 'new'; blockType: BlockType } | { kind: 'move'; id: string };

export function setDragData(dataTransfer: DataTransfer, data: DragData): void {
  dataTransfer.setData(DRAG_TYPE, JSON.stringify(data));
}

/** Reads drag data and checks it, because anything can be dropped on the page (e.g. text from another site). */
export function readDragData(dataTransfer: DataTransfer): DragData | null {
  try {
    const data = JSON.parse(dataTransfer.getData(DRAG_TYPE));
    if (data?.kind === 'new' && BLOCK_TYPES.includes(data.blockType)) {
      return { kind: 'new', blockType: data.blockType as BlockType };
    }
    if (data?.kind === 'move' && typeof data.id === 'string') {
      return { kind: 'move', id: data.id };
    }
  } catch {
    // not our data
  }
  return null;
}
