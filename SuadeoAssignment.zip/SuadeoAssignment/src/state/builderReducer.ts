import type { Block, BlockChanges, BlockType } from '../types/block';
import { MAX_BLOCKS, clamp, createBlock } from '../utils/helpers';
import { sanitizeBlock } from '../utils/validate';

const HISTORY_LIMIT = 50;

/**
 * The builder state. The canvas is drawn from `blocks` — the single source of truth.
 * `past` and `future` hold earlier/later versions of `blocks` for undo/redo.
 */
export interface BuilderState {
  blocks: Block[];
  selectedId: string | null;
  past: Block[][];
  future: Block[][];
}

export type BuilderAction =
  | { type: 'add'; blockType: BlockType; index?: number }
  | { type: 'move'; id: string; toIndex: number }
  | { type: 'update'; id: string; changes: BlockChanges }
  | { type: 'delete'; id: string }
  | { type: 'select'; id: string | null }
  | { type: 'load'; blocks: Block[] }
  | { type: 'undo' }
  | { type: 'redo' };

export function createInitialState(blocks: Block[] = []): BuilderState {
  return { blocks, selectedId: null, past: [], future: [] };
}

function sameBlock(a: Block, b: Block): boolean {
  return (Object.keys(a) as (keyof Block)[]).every((key) => a[key] === b[key]);
}

/** Applies one layout change. Returns the same state object when nothing changed. */
function applyAction(state: BuilderState, action: BuilderAction): BuilderState {
  switch (action.type) {
    case 'add': {
      if (state.blocks.length >= MAX_BLOCKS) return state;
      const block = createBlock(action.blockType);
      const blocks = [...state.blocks];
      const index = clamp(action.index ?? blocks.length, 0, blocks.length);
      blocks.splice(index, 0, block);
      return { ...state, blocks, selectedId: block.id };
    }

    case 'move': {
      // toIndex = "insert before the block that is at this index now".
      const from = state.blocks.findIndex((b) => b.id === action.id);
      if (from === -1) return state;
      let to = clamp(action.toIndex, 0, state.blocks.length);
      if (from < to) to -= 1; // removing the block shifts later indexes by one
      if (to === from) return state;
      const blocks = [...state.blocks];
      const [moved] = blocks.splice(from, 1);
      blocks.splice(to, 0, moved);
      return { ...state, blocks };
    }

    case 'update': {
      const index = state.blocks.findIndex((b) => b.id === action.id);
      if (index === -1) return state;
      const current = state.blocks[index];
      const updated = sanitizeBlock({ ...current, ...action.changes });
      if (!updated || sameBlock(updated, current)) return state;
      // Only the edited block becomes a new object. Every other block keeps the
      // same reference, so React.memo skips re-rendering them.
      const blocks = [...state.blocks];
      blocks[index] = updated;
      return { ...state, blocks };
    }

    case 'delete': {
      if (!state.blocks.some((b) => b.id === action.id)) return state;
      return {
        ...state,
        blocks: state.blocks.filter((b) => b.id !== action.id),
        selectedId: state.selectedId === action.id ? null : state.selectedId,
      };
    }

    case 'select':
      return state.selectedId === action.id ? state : { ...state, selectedId: action.id };

    case 'load':
      return { ...state, blocks: action.blocks, selectedId: null };

    default:
      return state;
  }
}

/** Keeps the selection only if the block still exists after undo/redo. */
function keepSelection(selectedId: string | null, blocks: Block[]): string | null {
  return selectedId !== null && blocks.some((b) => b.id === selectedId) ? selectedId : null;
}

export function builderReducer(state: BuilderState, action: BuilderAction): BuilderState {
  if (action.type === 'undo') {
    if (state.past.length === 0) return state;
    const previous = state.past[state.past.length - 1];
    return {
      blocks: previous,
      selectedId: keepSelection(state.selectedId, previous),
      past: state.past.slice(0, -1),
      future: [state.blocks, ...state.future],
    };
  }

  if (action.type === 'redo') {
    if (state.future.length === 0) return state;
    const next = state.future[0];
    return {
      blocks: next,
      selectedId: keepSelection(state.selectedId, next),
      past: [...state.past, state.blocks],
      future: state.future.slice(1),
    };
  }

  const next = applyAction(state, action);
  // Selection changes and no-op edits don't create an undo step.
  if (next.blocks === state.blocks) return next;
  return { ...next, past: [...state.past, state.blocks].slice(-HISTORY_LIMIT), future: [] };
}
