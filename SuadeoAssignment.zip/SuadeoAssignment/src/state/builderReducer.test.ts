import { describe, expect, it } from 'vitest';
import { createBlock } from '../utils/helpers';
import { builderReducer, createInitialState, type BuilderState } from './builderReducer';

function stateWith(...types: ('text' | 'image' | 'button' | 'container')[]): BuilderState {
  return createInitialState(types.map((type) => createBlock(type)));
}

const ids = (state: BuilderState) => state.blocks.map((b) => b.id);

describe('builderReducer', () => {
  it('adds a block at the given index and selects it', () => {
    const start = stateWith('text', 'image');
    const next = builderReducer(start, { type: 'add', blockType: 'button', index: 1 });
    expect(next.blocks.map((b) => b.type)).toEqual(['text', 'button', 'image']);
    expect(next.selectedId).toBe(next.blocks[1].id);
  });

  it('moves a block forward and backward', () => {
    const start = stateWith('text', 'image', 'button');
    const [a, b, c] = ids(start);
    expect(ids(builderReducer(start, { type: 'move', id: a, toIndex: 3 }))).toEqual([b, c, a]);
    expect(ids(builderReducer(start, { type: 'move', id: c, toIndex: 0 }))).toEqual([c, a, b]);
  });

  it('ignores a move to the same place', () => {
    const start = stateWith('text', 'image');
    expect(builderReducer(start, { type: 'move', id: start.blocks[0].id, toIndex: 1 })).toBe(start);
  });

  it('updates only the edited block (other blocks keep the same object)', () => {
    const start = stateWith('text', 'image');
    const next = builderReducer(start, { type: 'update', id: start.blocks[0].id, changes: { text: 'Hello' } });
    expect(next.blocks[0].text).toBe('Hello');
    expect(next.blocks[1]).toBe(start.blocks[1]);
  });

  it('rejects unsafe values in an update', () => {
    const start = stateWith('button');
    const id = start.blocks[0].id;
    const next = builderReducer(start, { type: 'update', id, changes: { color: 'red; background: url(x)', fontSize: 9999 } });
    expect(next.blocks[0].color).toBe('#ffffff'); // default kept
    expect(next.blocks[0].fontSize).toBe(72); // clamped to the maximum
  });

  it('deletes a block and clears its selection', () => {
    const start = builderReducer(stateWith('text'), { type: 'select', id: null });
    const id = start.blocks[0].id;
    const selected = builderReducer(start, { type: 'select', id });
    const next = builderReducer(selected, { type: 'delete', id });
    expect(next.blocks).toHaveLength(0);
    expect(next.selectedId).toBeNull();
  });

  it('undoes and redoes changes', () => {
    const start = stateWith('text');
    const added = builderReducer(start, { type: 'add', blockType: 'image' });
    const undone = builderReducer(added, { type: 'undo' });
    expect(undone.blocks).toBe(start.blocks);
    const redone = builderReducer(undone, { type: 'redo' });
    expect(redone.blocks).toBe(added.blocks);
  });

  it('does not add an undo step for selection changes', () => {
    const start = stateWith('text');
    const next = builderReducer(start, { type: 'select', id: start.blocks[0].id });
    expect(next.past).toHaveLength(0);
  });

  it('clears redo history after a new change', () => {
    const added = builderReducer(stateWith('text'), { type: 'add', blockType: 'image' });
    const undone = builderReducer(added, { type: 'undo' });
    const changed = builderReducer(undone, { type: 'add', blockType: 'button' });
    expect(changed.future).toHaveLength(0);
  });
});
