import { memo, type ReactNode } from 'react';
import { ALIGNS, WIDTHS, type Align, type Block, type BlockChanges, type BlockWidth } from '../types/block';
import { BLOCK_LABELS, FONT_SIZE, HEIGHT, TEXT_MAX_LENGTH, URL_MAX_LENGTH, safeUrl } from '../utils/helpers';

interface PropertiesPanelProps {
  block: Block | null;
  index: number;
  total: number;
  onChange: (id: string, changes: BlockChanges) => void;
  onMove: (id: string, toIndex: number) => void;
  onDelete: (id: string) => void;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
    </label>
  );
}

const TEXT_LABEL = { text: 'Text', image: 'Alt text', button: 'Button label', container: 'Title' } as const;

/** Edits the selected block. Every change goes straight to the state, so the canvas updates live. */
export const PropertiesPanel = memo(function PropertiesPanel({ block, index, total, onChange, onMove, onDelete }: PropertiesPanelProps) {
  if (!block) {
    return (
      <aside className="panel properties">
        <h2 className="panel-title">Properties</h2>
        <p className="panel-hint">Select a block on the page to edit it.</p>
      </aside>
    );
  }

  const change = (changes: BlockChanges) => onChange(block.id, changes);
  const showUrl = block.type === 'image' || block.type === 'button';
  const urlInvalid = block.url.trim() !== '' && safeUrl(block.url) === null;

  return (
    <aside className="panel properties">
      <h2 className="panel-title">{BLOCK_LABELS[block.type]} properties</h2>

      <Field label={TEXT_LABEL[block.type]}>
        {block.type === 'text' ? (
          <textarea rows={4} maxLength={TEXT_MAX_LENGTH} value={block.text} onChange={(e) => change({ text: e.target.value })} />
        ) : (
          <input type="text" maxLength={TEXT_MAX_LENGTH} value={block.text} onChange={(e) => change({ text: e.target.value })} />
        )}
      </Field>

      {showUrl && (
        <Field label={block.type === 'image' ? 'Image URL' : 'Link URL'}>
          <input
            type="url"
            placeholder="https://"
            maxLength={URL_MAX_LENGTH}
            value={block.url}
            aria-invalid={urlInvalid}
            onChange={(e) => change({ url: e.target.value })}
          />
          {urlInvalid && <span className="field-error">Only full http:// or https:// addresses are used.</span>}
        </Field>
      )}

      {block.type === 'text' && (
        <Field label={`Font size: ${block.fontSize}px`}>
          <input
            type="range"
            min={FONT_SIZE.min}
            max={FONT_SIZE.max}
            value={block.fontSize}
            onChange={(e) => change({ fontSize: Number(e.target.value) })}
          />
        </Field>
      )}

      {(block.type === 'image' || block.type === 'container') && (
        <Field label={`Height: ${block.height}px`}>
          <input type="range" min={HEIGHT.min} max={HEIGHT.max} value={block.height} onChange={(e) => change({ height: Number(e.target.value) })} />
        </Field>
      )}

      {block.type !== 'image' && (
        <div className="field-row">
          <Field label="Text colour">
            <input type="color" value={block.color} onChange={(e) => change({ color: e.target.value })} />
          </Field>
          {block.type !== 'text' && (
            <Field label="Background">
              <input type="color" value={block.background} onChange={(e) => change({ background: e.target.value })} />
            </Field>
          )}
        </div>
      )}

      {block.type !== 'image' && (
        <Field label="Alignment">
          <select value={block.align} onChange={(e) => change({ align: e.target.value as Align })}>
            {ALIGNS.map((align) => (
              <option key={align} value={align}>
                {align}
              </option>
            ))}
          </select>
        </Field>
      )}

      <Field label="Width">
        <select value={block.width} onChange={(e) => change({ width: e.target.value as BlockWidth })}>
          {WIDTHS.map((width) => (
            <option key={width} value={width}>
              {width === 'full' ? 'Full width' : width === 'half' ? 'Half' : 'One third'}
            </option>
          ))}
        </select>
      </Field>

      <div className="button-row">
        <button type="button" onClick={() => onMove(block.id, index - 1)} disabled={index === 0}>
          Move up
        </button>
        <button type="button" onClick={() => onMove(block.id, index + 2)} disabled={index === total - 1}>
          Move down
        </button>
      </div>
      <button type="button" className="danger" onClick={() => onDelete(block.id)}>
        Delete block
      </button>
    </aside>
  );
});
