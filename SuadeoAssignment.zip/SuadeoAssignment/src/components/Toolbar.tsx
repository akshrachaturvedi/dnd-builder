import { memo, useRef, type ChangeEvent } from 'react';
import type { StatusMessage } from '../hooks/useBuilder';

interface ToolbarProps {
  blockCount: number;
  message: StatusMessage | null;
  importing: boolean;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onSave: () => void;
  onLoad: () => void;
  onExport: () => void;
  onImport: (file: File) => void;
  onClear: () => void;
}

export const Toolbar = memo(function Toolbar({
  blockCount,
  message,
  importing,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onSave,
  onLoad,
  onExport,
  onImport,
  onClear,
}: ToolbarProps) {
  const fileInput = useRef<HTMLInputElement>(null);

  const handleFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = ''; // so the same file can be chosen again
    if (file) onImport(file);
  };

  const handleClear = () => {
    if (blockCount > 0 && window.confirm('Remove all blocks from the page? You can undo this.')) onClear();
  };

  return (
    <header className="toolbar">
      <h1 className="toolbar-title">
        Page Builder <span className="toolbar-count">{blockCount} blocks</span>
      </h1>

      <div className="toolbar-actions">
        <button type="button" onClick={onUndo} disabled={!canUndo} title="Undo (Ctrl+Z)">
          Undo
        </button>
        <button type="button" onClick={onRedo} disabled={!canRedo} title="Redo (Ctrl+Y)">
          Redo
        </button>
        <button type="button" onClick={onSave}>
          Save
        </button>
        <button type="button" onClick={onLoad}>
          Load saved
        </button>
        <button type="button" onClick={onExport}>
          Export JSON
        </button>
        <button type="button" onClick={() => fileInput.current?.click()} disabled={importing}>
          {importing ? 'Importing…' : 'Import JSON'}
        </button>
        <input ref={fileInput} type="file" accept=".json,application/json" hidden onChange={handleFile} />
        <button type="button" className="danger" onClick={handleClear} disabled={blockCount === 0}>
          Clear
        </button>
      </div>

      {message && (
        <p className={`status status-${message.kind}`} role="status">
          {message.text}
        </p>
      )}
    </header>
  );
});
