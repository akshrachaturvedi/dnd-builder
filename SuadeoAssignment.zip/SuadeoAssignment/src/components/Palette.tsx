import { memo } from 'react';
import { BLOCK_TYPES, type BlockType } from '../types/block';
import { BLOCK_LABELS, setDragData } from '../utils/helpers';

interface PaletteProps {
  canAdd: boolean;
  onAdd: (blockType: BlockType) => void;
}

/** Block types the user can drag onto the canvas (or click to add at the end). */
export const Palette = memo(function Palette({ canAdd, onAdd }: PaletteProps) {
  return (
    <aside className="panel palette">
      <h2 className="panel-title">Blocks</h2>
      <div className="palette-list">
        {BLOCK_TYPES.map((type) => (
          <button
            key={type}
            type="button"
            className="palette-item"
            draggable={canAdd}
            disabled={!canAdd}
            onDragStart={(event) => setDragData(event.dataTransfer, { kind: 'new', blockType: type })}
            onClick={() => onAdd(type)}
          >
            {BLOCK_LABELS[type]}
          </button>
        ))}
      </div>
      <p className="panel-hint">Drag a block onto the page, or click to add it at the end.</p>
      {!canAdd && <p className="panel-hint">Block limit reached.</p>}
    </aside>
  );
});
