import { memo, useCallback, useMemo, type CSSProperties, type DragEvent } from 'react';
import type { Block as BlockData } from '../types/block';
import { BLOCK_LABELS, safeUrl, setDragData } from '../utils/helpers';

export type DropSide = 'before' | 'after' | null;

interface BlockProps {
  block: BlockData;
  isSelected: boolean;
  dropSide: DropSide;
  onSelect: (id: string) => void;
  onDragOverBlock: (id: string, before: boolean) => void;
  onDragEnd: () => void;
}

/** What the block shows. User text is always rendered as plain text (React escapes it). */
function BlockContent({ block }: { block: BlockData }) {
  const style = useMemo<CSSProperties>(
    () => ({
      color: block.color,
      background: block.type === 'text' ? undefined : block.background,
      fontSize: block.type === 'text' ? block.fontSize : undefined,
      textAlign: block.align,
      minHeight: block.type === 'image' || block.type === 'container' ? block.height : undefined,
    }),
    [block.type, block.color, block.background, block.fontSize, block.align, block.height],
  );
  const url = safeUrl(block.url); // checked again right before use

  switch (block.type) {
    case 'text':
      return (
        <p className="content-text" style={style}>
          {block.text}
        </p>
      );
    case 'image':
      return url ? (
        <img className="content-image" src={url} alt={block.text} style={{ height: block.height }} draggable={false} />
      ) : (
        <div className="content-placeholder" style={{ height: block.height }}>
          Add an image URL in the properties panel
        </div>
      );
    case 'button':
      return (
        <div className="content-button-row" style={{ justifyContent: block.align }}>
          <a
            className="content-button"
            style={style}
            href={url ?? undefined}
            target="_blank"
            rel="noopener noreferrer"
            draggable={false}
            onClick={(event) => event.preventDefault()} // don't navigate while editing
          >
            {block.text}
          </a>
        </div>
      );
    case 'container':
      return (
        <div className="content-container" style={style}>
          <strong>{block.text}</strong>
        </div>
      );
  }
}

/**
 * A block on the canvas. Wrapped in React.memo: it only re-renders when its own
 * props change. Editing or moving another block doesn't touch this one.
 * It doesn't receive its position index, so reordering doesn't re-render it either.
 */
export const Block = memo(function Block({
  block,
  isSelected,
  dropSide,
  onSelect,
  onDragOverBlock,
  onDragEnd,
}: BlockProps) {
  const handleDragStart = useCallback(
    (event: DragEvent<HTMLDivElement>) => {
      setDragData(event.dataTransfer, { kind: 'move', id: block.id });
      event.dataTransfer.effectAllowed = 'move';
    },
    [block.id],
  );

  // Pointer on the left half → drop before this block, right half → after it.
  const handleDragOver = useCallback(
    (event: DragEvent<HTMLDivElement>) => {
      event.preventDefault();
      event.stopPropagation();
      const rect = event.currentTarget.getBoundingClientRect();
      onDragOverBlock(block.id, event.clientX < rect.left + rect.width / 2);
    },
    [block.id, onDragOverBlock],
  );

  const className = [
    'block',
    `width-${block.width}`,
    isSelected ? 'is-selected' : '',
    dropSide ? `drop-${dropSide}` : '',
  ].join(' ');

  return (
    <div
      className={className}
      draggable
      tabIndex={0}
      role="button"
      aria-pressed={isSelected}
      aria-label={`${BLOCK_LABELS[block.type]} block`}
      onClick={() => onSelect(block.id)}
      onKeyDown={(event) => event.key === 'Enter' && onSelect(block.id)}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={onDragEnd}
    >
      <BlockContent block={block} />
    </div>
  );
});
