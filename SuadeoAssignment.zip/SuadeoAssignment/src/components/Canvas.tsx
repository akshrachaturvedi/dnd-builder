import { useCallback, useState, type DragEvent } from 'react';
import type { Block as BlockData, BlockType } from '../types/block';
import { readDragData } from '../utils/helpers';
import { Block } from './Block';

interface CanvasProps {
  blocks: BlockData[];
  selectedId: string | null;
  onAdd: (blockType: BlockType, index: number) => void;
  onMove: (id: string, toIndex: number) => void;
  onSelect: (id: string | null) => void;
}

/** Where the dragged item will land: next to a block, or at the end of the page. */
type DropTarget = { id: string; before: boolean } | 'end' | null;

/**
 * The page being built. It is drawn from the `blocks` state only.
 * Drag and drop uses the browser's native HTML5 drag events:
 * while dragging, the browser draws the drag image, and React state changes
 * only when the drop position changes and once on drop.
 */
export function Canvas({ blocks, selectedId, onAdd, onMove, onSelect }: CanvasProps) {
  const [dropTarget, setDropTarget] = useState<DropTarget>(null);

  // Returning the previous value when nothing changed makes React skip the re-render,
  // so the many dragover events fired per second cost nothing.
  const handleDragOverBlock = useCallback((id: string, before: boolean) => {
    setDropTarget((prev) => (prev !== null && prev !== 'end' && prev.id === id && prev.before === before ? prev : { id, before }));
  }, []);
  const clearDropTarget = useCallback(() => setDropTarget(null), []);

  const handleDragOver = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault(); // allows dropping
    if (event.target === event.currentTarget) setDropTarget('end'); // empty area → end of page
  };

  const handleDragLeave = (event: DragEvent<HTMLDivElement>) => {
    // Pointer left the canvas (out of bounds) → hide the drop marker.
    if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDropTarget(null);
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    let index = blocks.length;
    if (dropTarget !== null && dropTarget !== 'end') {
      const targetIndex = blocks.findIndex((b) => b.id === dropTarget.id);
      if (targetIndex !== -1) index = dropTarget.before ? targetIndex : targetIndex + 1;
    }
    setDropTarget(null);
    const data = readDragData(event.dataTransfer);
    if (!data) return; // something else was dropped (e.g. text from another page) → ignore
    if (data.kind === 'new') onAdd(data.blockType, index);
    else onMove(data.id, index);
  };

  return (
    <main className="canvas-area">
      <div
        className="canvas"
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={(event) => event.target === event.currentTarget && onSelect(null)}
        aria-label="Canvas"
      >
        {blocks.length === 0 && (
          <div className="canvas-empty">
            <strong>Your page is empty</strong>
            <span>Drag a block here, or click one in the palette.</span>
          </div>
        )}

        {blocks.map((block) => (
          <Block
            key={block.id}
            block={block}
            isSelected={block.id === selectedId}
            dropSide={dropTarget !== null && dropTarget !== 'end' && dropTarget.id === block.id ? (dropTarget.before ? 'before' : 'after') : null}
            onSelect={onSelect}
            onDragOverBlock={handleDragOverBlock}
            onDragEnd={clearDropTarget}
          />
        ))}

        {dropTarget === 'end' && blocks.length > 0 && <div className="drop-end" />}
      </div>
    </main>
  );
}
