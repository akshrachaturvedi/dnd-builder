export type BlockType = 'text' | 'image' | 'button' | 'container';
export type Align = 'left' | 'center' | 'right';
export type BlockWidth = 'full' | 'half' | 'third';

export const BLOCK_TYPES: BlockType[] = ['text', 'image', 'button', 'container'];
export const ALIGNS: Align[] = ['left', 'center', 'right'];
export const WIDTHS: BlockWidth[] = ['full', 'half', 'third'];

/**
 * One shape for every block. Each type uses the fields it needs:
 * - text:      text, fontSize, color, align
 * - image:     url (image address), text (alt text), height
 * - button:    text (label), url (link), color, background, align
 * - container: text (title), color, background, height, align
 */
export interface Block {
  id: string;
  type: BlockType;
  text: string;
  url: string;
  color: string;
  background: string;
  fontSize: number;
  height: number;
  align: Align;
  width: BlockWidth;
}

/** The fields the properties panel is allowed to change. */
export type BlockChanges = Partial<Omit<Block, 'id' | 'type'>>;
