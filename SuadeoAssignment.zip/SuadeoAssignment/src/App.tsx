import { Canvas } from './components/Canvas';
import { Palette } from './components/Palette';
import { PropertiesPanel } from './components/PropertiesPanel';
import { Toolbar } from './components/Toolbar';
import { useBuilder } from './hooks/useBuilder';

/** Layout only — all logic is in the useBuilder hook. */
export default function App() {
  const builder = useBuilder();
  const selectedIndex = builder.blocks.findIndex((block) => block.id === builder.selectedId);

  return (
    <div className="app">
      <Toolbar
        blockCount={builder.blocks.length}
        message={builder.message}
        importing={builder.importing}
        canUndo={builder.canUndo}
        canRedo={builder.canRedo}
        onUndo={builder.undo}
        onRedo={builder.redo}
        onSave={builder.save}
        onLoad={builder.loadSaved}
        onExport={builder.exportJson}
        onImport={builder.importJson}
        onClear={builder.clearAll}
      />
      <div className="workspace">
        <Palette canAdd={builder.canAdd} onAdd={builder.addBlock} />
        <Canvas
          blocks={builder.blocks}
          selectedId={builder.selectedId}
          onAdd={builder.addBlock}
          onMove={builder.moveBlock}
          onSelect={builder.selectBlock}
        />
        <PropertiesPanel
          block={builder.selectedBlock}
          index={selectedIndex}
          total={builder.blocks.length}
          onChange={builder.updateBlock}
          onMove={builder.moveBlock}
          onDelete={builder.deleteBlock}
        />
      </div>
    </div>
  );
}
