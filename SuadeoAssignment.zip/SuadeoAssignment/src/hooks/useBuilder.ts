import { useCallback, useEffect, useMemo, useReducer, useState } from 'react';
import { builderReducer, createInitialState } from '../state/builderReducer';
import type { Block, BlockChanges, BlockType } from '../types/block';
import { MAX_BLOCKS } from '../utils/helpers';
import { downloadJson, loadFromStorage, saveToStorage, toJson } from '../utils/serialize';
import { parseLayout } from '../utils/validate';

export interface StatusMessage {
  kind: 'success' | 'error';
  text: string;
}

/** Restores the saved layout when the app starts. */
function loadInitialBlocks(): { blocks: Block[]; message: StatusMessage | null } {
  const saved = loadFromStorage();
  if (!saved) return { blocks: [], message: null };
  if (!saved.ok) return { blocks: [], message: { kind: 'error', text: `Saved layout could not be loaded: ${saved.error}` } };
  return { blocks: saved.blocks, message: null };
}

/**
 * All builder logic lives here, so components only display data and call these functions.
 * The action functions are created once (useCallback with only `dispatch`), so passing
 * them to memoised components never causes extra re-renders.
 */
export function useBuilder() {
  const [initial] = useState(loadInitialBlocks);
  const [state, dispatch] = useReducer(builderReducer, initial.blocks, createInitialState);
  const [message, setMessage] = useState<StatusMessage | null>(initial.message);
  const [importing, setImporting] = useState(false);

  // Hide the status message after 4 seconds.
  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => setMessage(null), 4000);
    return () => window.clearTimeout(timer);
  }, [message]);

  /* ---------- block actions ---------- */

  const addBlock = useCallback((blockType: BlockType, index?: number) => {
    dispatch({ type: 'add', blockType, index });
  }, []);

  const moveBlock = useCallback((id: string, toIndex: number) => {
    dispatch({ type: 'move', id, toIndex });
  }, []);

  const updateBlock = useCallback((id: string, changes: BlockChanges) => {
    dispatch({ type: 'update', id, changes });
  }, []);

  const deleteBlock = useCallback((id: string) => {
    dispatch({ type: 'delete', id });
  }, []);

  const selectBlock = useCallback((id: string | null) => {
    dispatch({ type: 'select', id });
  }, []);

  const undo = useCallback(() => dispatch({ type: 'undo' }), []);
  const redo = useCallback(() => dispatch({ type: 'redo' }), []);

  // Keyboard: Ctrl/Cmd+Z undo, Ctrl/Cmd+Shift+Z or Ctrl+Y redo.
  // Ignored while typing in a field, so the browser's own text undo still works there.
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement;
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName)) return;
      if (!(event.ctrlKey || event.metaKey)) return;
      const key = event.key.toLowerCase();
      if (key === 'z' && !event.shiftKey) {
        event.preventDefault();
        undo();
      } else if ((key === 'z' && event.shiftKey) || key === 'y') {
        event.preventDefault();
        redo();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [undo, redo]);

  /* ---------- save / load ---------- */

  const save = useCallback(() => {
    const ok = saveToStorage(state.blocks);
    setMessage(ok ? { kind: 'success', text: 'Layout saved.' } : { kind: 'error', text: 'Could not save. Browser storage is full or disabled.' });
  }, [state.blocks]);

  const loadSaved = useCallback(() => {
    const saved = loadFromStorage();
    if (!saved) return setMessage({ kind: 'error', text: 'There is no saved layout yet.' });
    if (!saved.ok) return setMessage({ kind: 'error', text: saved.error });
    dispatch({ type: 'load', blocks: saved.blocks });
    setMessage({ kind: 'success', text: 'Saved layout loaded.' });
  }, []);

  const exportJson = useCallback(() => {
    if (state.blocks.length === 0) return setMessage({ kind: 'error', text: 'Add a block before exporting.' });
    downloadJson(toJson(state.blocks), 'layout.json');
    setMessage({ kind: 'success', text: 'Layout exported.' });
  }, [state.blocks]);

  const importJson = useCallback(async (file: File) => {
    setImporting(true);
    try {
      const result = parseLayout(await file.text());
      if (!result.ok) return setMessage({ kind: 'error', text: result.error });
      dispatch({ type: 'load', blocks: result.blocks });
      const note = result.skipped > 0 ? ` ${result.skipped} invalid block(s) were skipped.` : '';
      setMessage({ kind: 'success', text: `Layout imported.${note}` });
    } catch {
      setMessage({ kind: 'error', text: 'The file could not be read.' });
    } finally {
      setImporting(false);
    }
  }, []);

  const clearAll = useCallback(() => {
    dispatch({ type: 'load', blocks: [] });
  }, []);

  /* ---------- derived data ---------- */

  const selectedBlock = useMemo(
    () => state.blocks.find((block) => block.id === state.selectedId) ?? null,
    [state.blocks, state.selectedId],
  );

  return {
    blocks: state.blocks,
    selectedId: state.selectedId,
    selectedBlock,
    canAdd: state.blocks.length < MAX_BLOCKS,
    canUndo: state.past.length > 0,
    canRedo: state.future.length > 0,
    message,
    importing,
    addBlock,
    moveBlock,
    updateBlock,
    deleteBlock,
    selectBlock,
    undo,
    redo,
    save,
    loadSaved,
    exportJson,
    importJson,
    clearAll,
  };
}
